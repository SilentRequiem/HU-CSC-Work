//
//  Amoo_LandmarksApp.swift
//  Amoo_Landmarks
//
//  Created by Michael Amoo on 3/17/25.
//

import SwiftUI

@main
struct Amoo_LandmarksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
