//
//  ViewController.swift
//  Light
//
//  Created by Michael Amoo on 1/26/25.
//

import UIKit

class ViewController: UIViewController {
    
    var lightOn = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI() //make it not show button at the start
        // Do any additional setup after loading the view.
    }

        func updateUI() { //changes the color
            view.backgroundColor = lightOn ? .white : .black //this below
        }
        
        
       /* if lightOn {
            view.backgroundColor = .white
            lightButton.setTitle("Off", for: .normal)
        } else {
            view.backgroundColor = .black
            lightButton.setTitle("On", for: .normal)
        } */
    
    @IBAction func buttonPressed(_ sender: Any) {
        lightOn.toggle()
        updateUI()
    }
}


