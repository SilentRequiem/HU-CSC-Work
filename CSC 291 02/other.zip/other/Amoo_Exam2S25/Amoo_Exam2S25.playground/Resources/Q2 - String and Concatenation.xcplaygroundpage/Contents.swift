/*:
## Question 2 - Define String and using + for String Concatenation

 You will read the comments to declare/define a constant variable and assign value to it
 
 */

// Declare a firstName constant and assign your own first name

// Declare a lastName constant and assign your own last name

// Declare a major constant and assign your own major

// Combine the strings into a fullName constant - make sure that you put a space in between

// Declare a lovesYourPostMessage with this value "loves your post"

// Combine your full name with lovessYourPostMessage into finishedMessage

// Combine your full name with major -- should say full name is majoring in ...



/*:

 TAKE SCREENSHOT of your code and and result, then move to the next question

 
[Previous Question 1](@previous)  |  page 3 of 5  |  [Next Question 3](@next)
 */
