//
//  ViewController.swift
//  Amoo_Photos
//
//  Created by Michael Amoo on 2/3/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

