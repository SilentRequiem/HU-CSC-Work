/*
Name: Michael Amoo
Instructor: Dr B.
Program: Lab 7 Inheritance
Date: 3/21/25
Description: Superclass and Extends
File: Driver
Class: CSC 152 02 / Lab Section 3
I, Michael Amoo, pledge to follow the Honor Code in completing my Lab 7.
*/
import java.util.Scanner;

public class AmooM_Lab7 {
   public static void main(String[] args) {
   
   Scanner keyboard = new Scanner(System.in); 


















   }
}