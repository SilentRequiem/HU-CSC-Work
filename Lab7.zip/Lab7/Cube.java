/*
   Square class - given for Lab 7
   CSC 152 - Spring 2025 
   UPDATE with your information below
   NAME : Michael Amoo
   Section: Lab S3 / 3/21/25
   Class: CSC 152 02
   ID : 00549396
   File: Cube - Class
   I, Michael Amoo, pledge to follow the Honor Code in completing my Lab 7.
*/


public class Cube extends Square {

   private String material;




























} 